:- ['list.pl'].

:- ([a,b,c],e) -->> E,E = [a,b,c].

:- (first([a,b,c]),e) -->> E,E = [a].

:- (rest([a,b,c]),e) -->> E,E = [b, c].

:- (add([a,b],first([c,d])),e) -->> E,E = [a, b, c].

program(
   assign(x,[a,b,c,d]) seq
   assign(y,[]) seq
   whiledo(x,
     assign(y,add(y,first(x))) seq
     assign(x,rest(x)))
).    

:- program(P),(P,e) -->> E,E = state([bind([], x), bind([a, b, c, d], y)|_],e).


