% pow-func.pl

:- ['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '     (fun(pow,'.
:- >>> '	    [b,p],'.
:- >>> '	    var(result) seq'.
:- >>> '	    if(eq(p,1),'.
:- >>> '	       assign(result,b),'.
:- >>> '	       assign(result,mult(b,call(pow,[assign(b,b),assign(p,sub(p,1))])))),'.
:- >>> '	    result) seq'.
:- >>> '	var(z) seq'.
:- >>> '	assign(z,call(pow,[assign(b,m),assign(p,n)]))'.
:- >>> 'is correct for a value of n=3 and m=2 and n>0'.
:- >>> 'pre(R) = initialstate(env([bind(2,m),bind(3,n)],s))'.
:- >>> 'post(T) = lookup(z,T,2^3)'.

program((fun(pow,
	    [b,p],
	    var(result) seq
	    if(eq(p,1),
	       assign(result,b),
	       assign(result,mult(b,call(pow,[assign(b,b),assign(p,sub(p,1))])))),
	    result) seq
	var(z) seq
	assign(z,call(pow,[assign(b,m),assign(p,n)])))).

:- >>> 'assume our precondition'.
initialstate(env([bind(2,m),bind(3,n)],s)).

:- program(P),initialstate(IS),(P,IS)-->>FS,lookup(z,FS,8).
