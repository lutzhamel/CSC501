% fact-func.pl

:- ['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '     (fun(fact,'.
:- >>> '	    [i],'.
:- >>> '	    var(result) seq'.
:- >>> '	    if(eq(i,1),'.
:- >>> '	       assign(result,1),'.
:- >>> '	       assign(result,mult(i,call(fact,[assign(i,sub(i,1))])))),'.
:- >>> '	    result) seq'.
:- >>> '	var(z) seq'.
:- >>> '	assign(z,call(fact,[assign(i,n)]))'.
:- >>> 'is correct for a value of n=3'.
:- >>> 'pre(R) = initialstate(env([bind(3,n)],s))'.
:- >>> 'post(T) = lookup(z,T,3!)'.

program((fun(fact,
	    [i],
	    var(result) seq
	    if(eq(i,1),
	       assign(result,1),
	       assign(result,mult(i,call(fact,[assign(i,sub(i,1))])))),
	    result) seq
	var(z) seq
	assign(z,call(fact,[assign(i,n)])))).

:- >>> 'assume our precondition'.
initialstate(env([bind(3,n)],s)).

:- program(P),initialstate(IS),(P,IS)-->>FS,lookup(z,FS,6).
