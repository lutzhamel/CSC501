% diff.pl
:-['sem-func.pl'].

:- >>> 'show that program P="assign(x,sub(i,j))"'.
:- >>> 'satisfies the program specification:'.
:- >>> ' pre(R) = initialstate(env([bind(vx,x),bind(vi,i),bind(vj,j)],s))'.
:- >>> ' post(T) = lookup(x,T,vi-vj)'.

program(assign(x,sub(i,j))).
                                                                                                   
:- >>> 'assert precondition'.                                                                      
:- asserta(initialstate(env([bind(vx,x),bind(vi,i),bind(vj,j)],s))).

:- >>> 'show that postcondition holds'.                                                            
:- program(P),
   initialstate(IS),
   (P,IS) -->> Q,
   lookup(x,Q,vi-vj).
