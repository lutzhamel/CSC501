% diff-func.pl
:-['sem-func.pl'].

:- >>> 'show that program P="fun(diff,[p,q],skip,sub(p,q)) seq assign(x,call(diff,[assign(p,i),assign(q,j)]))"'.
:- >>> 'satisfies the program specification:'.
:- >>> ' pre(R) = initialstate(env([bind(vx,x),bind(vi,i),bind(vj,j)],s))'.
:- >>> ' post(T) = lookup(x,T,vi-vj)'.

program((fun(diff,[p,q],skip,sub(p,q)) seq assign(x,call(diff,[assign(p,i),assign(q,j)])))).
                                                                                                   
:- >>> 'assert precondition'.                                                                      
:- asserta(initialstate(env([bind(vx,x),bind(vi,i),bind(vj,j)],s))).

:- >>> 'show that postcondition holds'.                                                            
:- program(P),
   initialstate(IS),
   (P,IS) -->> Q,
   lookup(x,Q,vi-vj).
