% pow-n-loop.pl

:- ['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '       var(i) seq'.
:- >>> '       var(z) seq'.
:- >>> '       assign(i,1) seq'.
:- >>> '       assign(z,m) seq'.
:- >>> '       whiledo(not(eq(i,n)),'.
:- >>> '               assign(i,add(i,1)) seq'.
:- >>> '               assign(z,mult(z,m))'.
:- >>> '       )'.
:- >>> 'is correct for any value of m and n with n>0'.
:- >>> 'pre(R) = initialstate(env([bind(vm,m),bind(vn,n)],s))'.
:- >>> 'post(T) = lookup(z,T,vm^vn)'.
:- >>> 'inv(Q) = lookup(i,Q,vi) ^ lookup(z,Q,vm^vi)'.

:- >>> 'define the parts of our program'.
init((var(i) seq var(z) seq assign(i,1) seq assign(z,m))).
guard(not(eq(i,n))).
body((assign(i,add(i,1)) seq assign(z,mult(z,m)))).

:- >>> 'define a model for our power operation'.
:- dynamic pow/3.

pow(B,1,B).

pow(B,P,R) :- 
    T1 is P-1,
    pow(B,T1,T2), 
    R is B*T2.

:- >>> 'first proof obligation'.
:- >>> 'assume precondition'.
:- asserta(initialstate(env([bind(vm,m),bind(vn,n)],s))).
:- >>> 'prove the invariant'.
:- init(P),initialstate(IS),(P,IS) -->> Q,lookup(i,Q,VI),lookup(z,Q,VZ),pow(vm,VI,VZ).
:- retract(initialstate(env([bind(vm,m),bind(vn,n)],s))).

:- >>> 'second  proof obligation'.
:- >>> 'assume invariant on s'.
:- asserta(initialstate(env([bind(vi,i),bind(vz,z),bind(vm,m),bind(vn,n)],s))).
:- asserta(pow(vm,vi,vz)).
% implies
:- asserta(pow(vm,vi+1,vz*vm)).
:- >>> 'assume guard on s'.
:- asserta((not(eq(i,n)),s) -->> true).
:- >>> 'prove the invariant on Q'.
:- body(Bd),initialstate(IS),(Bd,IS) -->> Q,lookup(i,Q,VI),lookup(z,Q,VZ),pow(vm,VI,VZ).
:- retract(initialstate(env([bind(vi,i),bind(vz,z),bind(vm,m),bind(vn,n)],s))).
:- retract(pow(vm,vi,vz)).
:- retract(pow(vm,vi+1,vz*vm)).
:- retract((not(eq(i,n)),s) -->> true).

:- >>> 'third  proof obligation'.
:- >>> 'assume the invariant on s'.
:- asserta(initialstate(env([bind(vi,i),bind(vz,z),bind(vm,m),bind(vn,n)],s))).
:- asserta(pow(vm,vi,vz)).
:- >>> 'assume NOT guard on any s'.
:- asserta((not(eq(i,n)),s) -->> not(true)).
% implies
:- asserta((eq(i,n),s) -->> true).
% implies
:- asserta(pow(vm,vn,vz)).
:- >>> 'prove postcondition on s'.
:- initialstate(IS),lookup(z,IS,VZ),pow(vm,vn,VZ).
:- retract(initialstate(env([bind(vi,i),bind(vz,z),bind(vm,m),bind(vn,n)],s))).
:- retract(pow(vm,vi,vz)).
:- retract((not(eq(i,n)),s) -->> not(true)).
:- retract((eq(i,n),s) -->> true).
:- retract(pow(vm,vn,vz)).

