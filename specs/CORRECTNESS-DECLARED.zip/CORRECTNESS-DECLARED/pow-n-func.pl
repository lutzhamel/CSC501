% pow-n-func.pl

:- ['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '     (fun(pow,'.
:- >>> '	    [b,p],'.
:- >>> '	    var(result) seq'.
:- >>> '	    if(eq(p,1),'.
:- >>> '	       assign(result,b),'.
:- >>> '	       assign(result,mult(b,call(pow,[assign(b,b),assign(p,sub(p,1))])))),'.
:- >>> '	    result) seq'.
:- >>> '	var(z) seq'.
:- >>> '	assign(z,call(pow,[assign(b,m),assign(p,n)]))'.
:- >>> 'is correct for any value of n and m and n>0'.
:- >>> 'pre(R) = initialstate(env([bind(vm,m),bind(vn,n)],s))'.
:- >>> 'post(T) = lookup(z,T,vm^vn)'.
:- >>> 'inv(Q) = lookup(b,Q,vb) ^ lookup(p,Q,vp) ^ lookup(result,Q,vb^vp)'.

:- >>> 'define the parts of our program'.
guard(eq(p,1)).
body1(var(result) seq assign(result,b)).
body2(var(result) seq assign(result,mult(b,call(pow,[assign(b,b),assign(p,sub(p,1))])))).
final(var(z) seq assign(z,result)).

:- >>> 'define a model for our power operation'.
:- dynamic pow/3.

pow(B,1,B).

pow(B,P,R) :- 
    T1 is P-1,
    pow(B,T1,T2), 
    R is B*T2.

:- >>> 'Proof by case analysis on recursion variable p'.
:- >>> 'first proof obligation'.
:- >>> 'assume call condition -- guard is true'.
:- asserta(initialstate(env([bind(vb,b),bind(1,p)],s))).
:- >>> 'prove the invariant'.
:- body1(P),initialstate(IS),(P,IS) -->> Q,lookup(b,Q,VB),lookup(p,Q,VP),lookup(result,Q,VR),pow(VB,VP,VR).
:- retract(initialstate(env([bind(vb,b),bind(1,p)],s))).

:- >>> 'second proof obligation'.
:- >>> 'assume call condition -- guard is false: vp =/= 1'.
:- asserta(initialstate(env([bind(vb,b),bind(vp,p)],s))).
% assume that the recursive call returns a value k
:- asserta((call(pow,[assign(b,b),assign(p,sub(p,1))]),S) -->> (k,S)).
% where the value k is defined as
:- asserta(pow(vb,vp-1,k)).
% which implies
:- asserta(pow(vb,vp,vb*k)).
:- >>> 'prove the invariant'.
:- body2(P),initialstate(IS),(P,IS) -->> Q,lookup(b,Q,VB),lookup(p,Q,VP),lookup(result,Q,VR),pow(VB,VP,VR).
:- retract(initialstate(env([bind(vb,b),bind(vp,p)],s))).
:- retract((call(pow,[assign(b,b),assign(p,sub(p,1))]),S) -->> (k,S)).
:- retract(pow(vb,vp-1,k)).
:- retract(pow(vb,vp,vb*k)).

:- >>> 'third proof obligation'.
:- >>> 'assume precondition -- result = q = vm^vn'.
:- >>> '   this follows from the second proof obligation with vp = vn'. 
:- asserta(initialstate(env([bind(vm,m),bind(vn,n),bind(q,result)],s))).
:- asserta(pow(vm,vn,q)).
:- >>> 'prove the post condition'.
:- final(P),initialstate(IS),(P,IS)-->>Q,lookup(z,Q,VZ),pow(vm,vn,VZ).
:- retract(initialstate(env([bind(vm,m),bind(vn,n),bind(q,result)],s))).
:- retract(pow(vm,vn,q)).


