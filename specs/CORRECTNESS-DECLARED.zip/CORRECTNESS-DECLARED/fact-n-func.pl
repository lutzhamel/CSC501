% fact-n-func.pl
:-['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '     (fun(fact,'.
:- >>> '	    [i],'.
:- >>> '	    var(result) seq'.
:- >>> '	    if(eq(i,1),'.
:- >>> '	       assign(result,1),'.
:- >>> '	       assign(result,mult(i,call(fact,[assign(i,sub(i,1))])))),'.
:- >>> '	    result) seq'.
:- >>> '	var(z) seq'.
:- >>> '	assign(z,call(fact,[assign(i,n)]))'.
:- >>> 'is correct for any value of n'.
:- >>> 'pre(R) = initialstate(env([bind(vn,n)],s))'.
:- >>> 'post(T) = lookup(z,T,n!)'.
:- >>> 'inv(Q) = lookup(i,Q,vi) ^ lookup(result,Q,vi!)'.

:- >>> 'define the parts of our program'.
guard(eq(i,1)).
body1(assign(result,1)).
body2(assign(result,mult(i,call(fact,[assign(i,sub(i,1))])))).
final(assign(z,result)).

:- >>> 'define our mathematical factorial operation'.
:- dynamic factorial/2.

factorial(1,1).

factorial(X,Y) :- 
    T1 is X-1,
    fact(T1,T2), 
    Y is X*T2.

:- >>> 'Proof by case analysis on i'.
:- >>> 'first proof obligation'.
:- >>> 'assume precondition -- guard is true'.
:- asserta(initialstate(env([bind(1,i),bind(0,result)],s))).
:- >>> 'prove the invariant'.
:- body1(P),initialstate(IS),(P,IS) -->> Q,lookup(i,Q,VI),lookup(result,Q,VR),factorial(VI,VR).
:- retract(initialstate(env([bind(1,i),bind(0,result)],s))).

:- >>> 'second proof obligation'.
:- >>> 'assume precondition -- guard is false: vi =/= 1'.
:- asserta(initialstate(env([bind(vi,i),bind(0,result)],s))).
% assume that the recursive call returns a value k
:- asserta((call(fact,[assign(i,sub(i,1))]),S) -->> (k,S)).
% where the value k is defined as
:- asserta(factorial(vi-1,k)).
% which implies
:- asserta(factorial(vi,vi*k)).
:- >>> 'prove the invariant'.
:- body2(P),initialstate(IS),(P,IS) -->> Q,lookup(i,Q,VI),lookup(result,Q,VR),factorial(VI,VR).
:- retract(initialstate(env([bind(vi,i),bind(0,result)],s))).
:- retract((call(fact,[assign(i,sub(i,1))]),S) -->> (k,S)).
:- retract(factorial(vi-1,k)).
:- retract(factorial(vi,vi*k)).

:- >>> 'third proof obligation'.
:- >>> 'assume precondition -- result = q = vn!'.
:- >>> '   this follows from the second proof obligation with vi = vn'. 
:- asserta(initialstate(env([bind(0,z),bind(q,result)],s))).
:- asserta(fact(vn,q)).
:- >>> 'prove the post condition'.
:- final(P),initialstate(IS),(P,IS)-->>Q,lookup(z,Q,VZ),fact(vn,VZ).
:- retract(initialstate(env([bind(0,z),bind(q,result)],s))).
:- retract(fact(vn,q)).


