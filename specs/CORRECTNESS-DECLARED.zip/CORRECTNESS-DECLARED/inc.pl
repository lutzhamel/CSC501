% inc.pl
:-['sem-func.pl'].

:- >>> 'show that program P="assign(x,add(x,1))"'.
:- >>> 'satisfies the program specification:'.
:- >>> ' pre(R) = initialstate(env([bind(vx,x)],s))'.
:- >>> ' post(T) = lookup(x,T,vx+1)'.

program(assign(x,add(x,1))).
                                                                                                   
:- >>> 'assert precondition'.                                                                      
:- asserta(initialstate(env([bind(vx,x)],s))).

:- >>> 'show that postcondition holds'.                                                            
:- program(P),
   initialstate(IS),
   (P,IS) -->> Q,
   lookup(x,Q,vx+1).
