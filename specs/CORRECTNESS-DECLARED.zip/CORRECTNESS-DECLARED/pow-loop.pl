% pow-loop.pl

:- ['sem-func.pl'].

:- >>> 'prove that the program p:'.
:- >>> '       var(i) seq'.
:- >>> '       var(z) seq'.
:- >>> '       assign(i,1) seq'.
:- >>> '       assign(z,m) seq'.
:- >>> '       whiledo(not(eq(i,n)),'.
:- >>> '               assign(i,add(i,1)) seq'.
:- >>> '               assign(z,mult(z,m))'.
:- >>> '       )'.
:- >>> 'is correct for a value of n=3 and m=2 for n>0'.
:- >>> 'pre(R) = initialstate(env([bind(2,m),bind(3,n)],s))'.
:- >>> 'post(T) = lookup(z,T,2^3)'.

program((var(i) seq var(z) seq
        assign(i,1) seq
        assign(z,m) seq
        whiledo(not(eq(i,n)),
             assign(i,add(i,1)) seq
             assign(z,mult(z,m))))).

:- >>> 'assume our precondition'.
initialstate(env([bind(2,m),bind(3,n)],s)).

:- program(P),initialstate(IS),(P,IS)-->>FS,lookup(z,FS,8).
