:- ['translate.pl'].


% it is sufficient to show that for every b in Bexp we have
%
%  (forall b,e)[(b,e) -->> V1 ^ 
%               translate(b,C) ^ 
%               (C,C,([],e)) --> ([V2],e) ^
%               V1 = V2]
%
% proof by induction on Bexp.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case true'.
:- (true,e) -->> V1,
   translate(true,C),
   (C,C,([],e)) -->> ([V2],e),
   V1 = V2.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case false'.
:- (false,e) -->> V1,
   translate(false,C),
   (C,C,([],e)) -->>([V2],e),
   V1 = V2.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the following assumptions hold for the relational operators
:- asserta((a,e) -->> va).  % arithmetic exp a -> va
:- asserta((b,e) -->> vb).  % arithmetic exp b -> vb
:- asserta(int(va)).
:- asserta(int(vb)).
:- asserta(translate(a,ca)).
:- asserta(translate(b,cb)).
:- asserta((ca,_,(S,E)) -->> ([va|S],E)).
:- asserta((cb,_,(S,E)) -->> ([vb|S],E)).

:- >>> 'case eq(a,b)'.
:- (eq(a,b),e) -->> V1,
   translate(eq(a,b),C),
   (C,C,([],e))  -->> ([V2],e),
   V1 = V2.

:- >>> 'case le(a,b)'.
:- (le(a,b),e) -->> V1,
   translate(le(a,b),C),
   (C,C,([],e)) -->> ([V2],e),
   V1 = V2.

:- retract((a,e) -->> va).
:- retract((b,e) -->> vb).
:- retract(int(va)).
:- retract(int(vb)).
:- retract(translate(a,ca)).
:- retract(translate(b,cb)).
:- retract((ca,_,(S,E)) -->> ([va|S],E)).
:- retract((cb,_,(S,E)) -->> ([vb|S],E)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- asserta((a,e) -->> va).
:- asserta((b,e) -->> vb).
:- asserta(bool(va)).
:- asserta(bool(vb)).
:- asserta(translate(a,ca)).
:- asserta(translate(b,cb)).
:- asserta((ca,_,(S,E)) -->> ([va|S],E)).
:- asserta((cb,_,(S,E)) -->> ([vb|S],E)).

:- >>> 'case not(a)'.
:- (not(a),e) -->> V1,
    translate(not(a),C),
    (C,C,([],e)) -->> ([V2],e),
    V1 = V2.

:- >>> 'case and(a,b)'.
:- (and(a,b),e) -->> V1,
    translate(and(a,b),C),
    (C,C,([],e)) -->> ([V2],e),
    V1 = V2.

:- >>> 'case or(a,b)'.
:- (or(a,b),e) -->> V1,
    translate(or(a,b),C),
    (C,C,([],e)) -->> ([V2],e),
    V1 = V2.

:- retract((a,e) -->> va).
:- retract((b,e) -->> vb).
:- retract(bool(va)).
:- retract(bool(vb)).
:- retract(translate(a,ca)).
:- retract(translate(b,cb)).
:- retract((ca,_,(S,E)) -->> ([va|S],E)).
:- retract((cb,_,(S,E)) -->> ([vb|S],E)).







