:- ['translate.pl'].


% it is sufficient to show that for every c in Com we have
%
%  (forall cc,e)[(cc,e) -->> E1) ^ 
%               translate(cc,C) ^ 
%               (C,C,([],e)) -->> ([],E1))]
%
% proof by induction on Com.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case skip'.
:- (skip,e) -->> E1,
    translate(skip,C),
    (C,C,([],e)) -->> ([],E1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case assign'.
:- asserta((a,e) -->> va).
:- asserta(int(va)).
:- asserta(translate(a,ca)).
:- asserta((ca,_,(L,S)) -->> ([va|L],S)).

:- (assign(x,a),e) -->> E1,
   translate(assign(x,a),C),
   (C,C,([],e)) -->> ([],E1).

:- retract((a,e) -->> va).
:- retract(int(va)).
:- retract(translate(a,ca)).
:- retract((ca,_,(L,S)) -->> ([va|L],S)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case seq'.
:- asserta((c1,_) -->> e1).
:- asserta((c2,e1) -->> e2).
:- asserta(translate(c1,cc1)).
:- asserta(translate(c2,cc2)).
:- asserta((cc1,_,([],_)) -->> ([],e1)).
:- asserta((cc2,_,([],e1)) -->> ([],e2)).

:- (seq(c1,c2),e) -->> E1,
    translate(seq(c1,c2),C),
    (C,C,([],e)) -->> ([],E1).

:- retract((c1,_) -->> e1).
:- retract((c2,e1) -->> e2).
:- retract(translate(c1,cc1)).
:- retract(translate(c2,cc2)).
:- retract((cc1,_,([],_)) -->> ([],e1)).
:- retract((cc2,_,([],e1)) -->> ([],e2)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case if'.
:- asserta((c1,e) -->> e1).
:- asserta((c2,e) -->> e2).
:- asserta(translate(b,cb)).
:- asserta(translate(c1,cc1)).
:- asserta(translate(c2,cc2)).
:- asserta((cc1,_,([],e)) -->> ([],e1)).
:- asserta((cc2,_,([],e)) -->> ([],e2)).

:- >>> '    case analysis, b=true'.
:- asserta((b,e) -->> true).
:- asserta((cb,_,([],e)) -->> ([true],e)).

:- (if(b,c1,c2),e) -->> E1,
    translate(if(b,c1,c2),C),
    (C,C,([],e)) -->> ([],E1).

:- retract((b,e) -->> true).
:- retract((cb,_,([],e)) -->> ([true],e)).

:- >>> '    case analysis, b=false'.
:- asserta((b,e) -->> false).
:- asserta((cb,_,([],e)) -->> ([false],e)).

:- (if(b,c1,c2),e) -->> E1,
    translate(if(b,c1,c2),C),
    (C,C,([],e)) -->> ([],E1).

:- retract((b,e) -->> false).
:- retract((cb,_,([],e)) -->> ([false],e)).

:- retract((c1,e) -->> e1).
:- retract((c2,e) -->> e2).
:- retract(translate(b,cb)).
:- retract(translate(c1,cc1)).
:- retract(translate(c2,cc2)).
:- retract((cc1,_,([],e)) -->> ([],e1)).
:- retract((cc2,_,([],e)) -->> ([],e2)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- >>> 'case while'.
:- asserta((c,e) -->> vc).
:- asserta(translate(b,cb)).
:- asserta(translate(c,cc)).
:- asserta((cc,_,([],e)) -->> ([],vc)).

:- >>> '    case analysis, b=false'.
:- asserta((b,e) -->> false).
:- asserta((cb,_,([],e)) -->> ([false],e)).

:- (whiledo(b,c),e) -->> e,
    translate(whiledo(b,c),C),
    (C,C,([],e)) -->> ([],e).

:- retract((b,e) -->> false).
:- retract((cb,_,([],e)) -->> ([false],e)).

:- >>> '    case analysis, b=true'.
:- asserta((b,e) -->> true).
:- asserta((cb,_,([],e)) -->> ([true],e)).

% lemma: prove that the translation of whiledo(b,c) is the piece of stack machine code shown
:- translate(
    whiledo(b,c),
    [label(whilelabel1),cb,jmpf(whilelabel2),cc,jmp(whilelabel1),label(whilelabel2)]).

% it is sufficient to prove the correctness for the loop for only one iteration
% assume that the remaining itereations after the first iteration give us some 
% terminal state vt - we assume this both in the source and target language
:- asserta((whiledo(b,c),vc) -->> vt). 
:- asserta(([label(whilelabel1),cb,jmpf(whilelabel2),cc,jmp(whilelabel1),label(whilelabel2)],
                _,([],vc)) -->> ([],vt)).

:- (whiledo(b,c),e) -->> vt,
    translate(whiledo(b,c),C),
    (C,C,([],e)) -->> ([],vt).

:- retract((b,e) -->> true).
:- retract((cb,_,([],e)) -->> ([true],e)).
:- retract((whiledo(b,c),vc) -->> vt). 
:- retract(([label(whilelabel1),cb,jmpf(whilelabel2),cc,jmp(whilelabel1),label(whilelabel2)],
                _,([],vc)) -->> ([],vt)).



