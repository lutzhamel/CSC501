% translation examples
:- ['translate.pl'].

:- >>> 'executing: assign(x,2) seq assign(y,mult(2,x))'.

program1(assign(x,2) seq assign(y,mult(2,x))).

:- >>> 'Source Semantics'.
:- program1(P),(P,e) -->> Env, Env = env([bind(4,y)|_],e).
:- >>> 'Target Semantics'.
:- program1(P),translate(P,C),(C,C,([],e)) -->> ([],Env), Env = env([bind(4,y)|_],e).

:- >>> 'executing: if(le(2,3),assign(i,3),assign(i,4))'.

program2(if(le(2,3),assign(i,3),assign(i,4))).

:- >>> 'Source Semantics'.
:- program2(P),(P,e) -->> Env, Env = env([bind(3,i)|_],e).
:- >>> 'Target Semantics'.
:- program2(P),translate(P,C),(C,C,([],e)) -->> ([],Env), Env = env([bind(3,i)|_],e).

:- >>> 'executing: '.
:- >>> 'assign(n,3) seq'.
:- >>> 'assign(i,1) seq'.
:- >>> 'assign(z,1) seq'.
:- >>> 'whiledo(not(eq(i,n)),'.
:- >>> '   assign(i,add(i,1)) seq'.
:- >>> '   assign(z,mult(z,i)))'.
program3(assign(n,3) seq
         assign(i,1) seq
         assign(z,1) seq
         whiledo(not(eq(i,n)),
           assign(i,add(i,1)) seq
           assign(z,mult(z,i)))).

:- >>> 'Source Semantics'.
:- program3(P),(P,e) -->> Env, Env = env([bind(6,z)|_],e).
:- >>> 'Target Semantics'.
:- program3(P),translate(P,C),(C,C,([],e)) -->> ([],Env), Env = env([bind(6,z)|_],e).